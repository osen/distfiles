#ifndef WILYNEWS_H
#define WILYNEWS_H

#include "headers.h"
#include "news.h"
#include "newsrc.h"
#include "nntp.h"
#include "post.h"

#endif /* WILYNEWS_H */
