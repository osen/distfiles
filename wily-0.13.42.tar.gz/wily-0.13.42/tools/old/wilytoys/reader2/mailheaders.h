#ifndef WILYMAIL_H
#define WILYMAIL_H

#include "headers.h"
#include "mbox.h"
#include "mail.h"
#include "membuf.h"

#endif /* WILYMAIL_H */
