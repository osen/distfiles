#ifndef RD_HEADERS_H
#define RD_HEADERS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>

#include <u.h>
#include <libc.h>
#include <util.h>
#include <libmsg.h>
#include "reader.h"
#include "proto.h"

#endif /* RD_HEADERS_H */
