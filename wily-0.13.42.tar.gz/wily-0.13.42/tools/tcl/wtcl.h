/*	$Header: /u/cvs/wtcl/wtcl.h,v 1.1.1.1 1996/11/12 21:28:09 cvs Exp $	*/

extern int	Wily_Init(Tcl_Interp*) ;
