#undef HAVE_ULONG
#undef HAVE_USHORT
#undef HAVE_UINT
#undef HAVE_UCHAR
#undef HAVE_CADDR_T

/* Defined if sprintf returns char * instead of int */
#undef BROKEN_SPRINTF

@TOP@
